import java.util.*;

public class ArrayShuffler {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7};
        shuffleArray(array);

        // Print the shuffled array
        for (int value : array) {
            System.out.print(value + " ");
        }
    }

    private static void shuffleArray(int[] array) {
        Random rand = new Random();

        for (int i = array.length - 1; i > 0; i--) {

            // Generate a random index

            int j = rand.nextInt(i + 1);

            // Swap elements at i and j

            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }
}
